ONLINE REPRODUCIBILITY PACKAGE

Primary manuscript: SCI_for_ratio_CV_DLNs_R1_Python_Empirical.docx (supplied separately).
Upload this package to the authors' selected public repository, then insert its URL in the manuscript Data Availability Statement. No repository has been published by this work.

Online_Results_and_Diagnostics_Python.docx: complete numerical simulation results and the updated Python empirical diagnostics.
simulation_summary.csv: final author-supplied 129 x 6 simulation summary, unchanged.
Table1b_data.csv: structured 24-scenario manuscript table data (144 method records).
figures/: Figure 3-5 PNG/PDF, plotting data and R session information. AL uses log10 with panel-specific scales. No finite lengths are capped.
make_Figures_3_5.R: R plotting script for simulation figures only.
Simulation_code/: Python simulation source.
Simulation_execution/: exact simulation settings and environment.
Empirical_Python3147/: complete Python 3.14.7 empirical driver, interval core, rainfall data, pinned requirements, Windows setup/test/full commands and README_TH.txt.
Empirical_Python3147/verified_results_full/: actual B=5000, bootstrap=5000, repeats=30 empirical results used in the updated manuscript. Includes Figure 6-7 PNG/SVG, Table 4, AD/bootstrap/block/seasonal/repeated results, NPZ arrays and validation reports.
Empirical_Python3147/verified_results_test/: smaller execution checks, not manuscript estimates.
Empirical_Python3147/reference_R_deterministic/: historical deterministic R references used to check CV, likelihood/AIC/BIC and observed AD formulas. These are not the primary empirical results.

Simulation code uses 10,000 attempts without replacement and 5,000 construction draws per stream. Conditional CP and AL use method-specific finite families. The Monte Carlo units are replication-level interval families, not individual pairs. Missing CP is not zero. Infinity flags may include numerical overflow.

All empirical randomization-based quantities were rerun using Python PCG64DXSM. Integer seeds shared between R and Python do not imply identical draws. The updated primary Table 4 includes one for Khonkaen/Kalasin under all six methods; repeated constructions still show endpoint variability for that pair.
