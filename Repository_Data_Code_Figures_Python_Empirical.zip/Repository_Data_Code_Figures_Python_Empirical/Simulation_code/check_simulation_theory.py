#!/usr/bin/env python
"""Deterministic theory, failure, denominator and transactional-resume checks."""
import json,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.special import gamma
from ziln_core import *
from design import make_design
from checkpoint import *

class TheoryTests(unittest.TestCase):
    def test_moments(self):
        for d in [.2,.5,.9]:
            for v in [.5,1,2]:
                for mu in [-2,0,2]:
                    p=1-d;ex=p*np.exp(mu+v/2);vx=p*np.exp(2*mu+v)*(np.exp(v)-p)
                    self.assertAlmostEqual(np.exp(logcv(v,p)),np.sqrt(vx)/ex,places=11)
    def test_priors(self):
        for a in [0,1]:
            r=7;S=3.5;b=(r-3)/2+a
            z=quad(lambda v:v**(-((r-1)/2+a))*np.exp(-S/(2*v)),0,np.inf)[0]
            self.assertAlmostEqual(z,gamma(b)*(S/2)**(-b),places=8)
    def test_hpd_original_scale(self):
        y=np.array([-2,-1,-.2,.1,.5,1,3,5,8,10]);mass=.7;count=int(np.ceil(len(y)*mass))
        ref=min([np.exp(y[[i,i+count-1]]) for i in range(len(y)-count+1)],key=lambda a:a[1]-a[0])
        np.testing.assert_array_equal(shortest_log(y,mass),ref)
        np.testing.assert_array_equal(ref,np.exp([-2,3]))
        for k,count in [(3,4917),(5,4975),(10,4995)]:self.assertEqual(int(np.ceil(5000*(1-.05/(k*(k-1)/2)))),count)
    def test_quantile8(self):
        # Independent implementation of Hyndman-Fan type 8.
        y=np.arange(1.,101);probs=[.001,.025,.5,.975,.999]
        def q(p):
            h=(len(y)+1/3)*p+1/3;j=int(np.floor(h));g=h-j
            if j<=0:return y[0]
            if j>=len(y):return y[-1]
            return (1-g)*y[j-1]+g*y[j]
        np.testing.assert_allclose(np.quantile(y,probs,method='median_unbiased'),[q(p) for p in probs],rtol=1e-14)
    def test_design_and_seeds(self):
        d=make_design('full');self.assertEqual(len(d),129);a=d[14]
        self.assertEqual((a['K'],a['n'],a['delta'],a['v']),(10,[50]*10,[.5]*10,[.5]*10))
        for k in [3,5,10]:
            a=next(a for a in d if a['label']=='scale_check' and a['K']==k)
            self.assertEqual(d[a['seed_case']-1]['label'],'aligned')
        self.assertEqual(len({seed_key(20261003,c,r,s) for c in range(1,130) for r in [1,2,10000] for s in range(8)}),129*3*8)
    def test_eligibility_and_streams(self):
        seeds=[seed_key(20261003,1,1,i) for i in range(1,7)]
        x=[np.array([0,1,2,3]),np.array([0,2,3,4]),np.array([0,3,4,5])];ci,d=intervals(x,seeds=seeds)
        for nm in ['ETI_Uniform','HPD_Uniform']:self.assertEqual(d['status'][nm],'ineligible')
        rng=rng_for(7);x=[generate(100,.2,0,.5,rng) for i in range(3)]
        ci,d=intervals(x,seeds=seeds);s2=seeds.copy();s2[4:]=[s+100 for s in s2[4:]];ci2,d2=intervals(x,seeds=s2)
        for nm in METHODS:
            self.assertEqual(d['status'][nm],'finite');np.testing.assert_array_equal(ci[nm],ci2[nm])
        scaled,_=intervals([xx*(i+2) for i,xx in enumerate(x)],seeds=seeds)
        for nm in METHODS:np.testing.assert_allclose(ci[nm],scaled[nm],rtol=1e-12)
        _,d=intervals([np.array([0,0,1]),np.array([0,1,2])],seeds=seeds)
        self.assertTrue(all(s=='ineligible' for s in d['status'].values()))
    def test_summary_and_categories(self):
        with tempfile.TemporaryDirectory() as tmp:
            db,_=open_db(tmp);x=[np.array([0,1,2,3,4])]*3;true=np.ones(3)
            dg=dict(positive=[4]*3,fiducial_failed=None,mathematically_eligible={nm:True for nm in METHODS},status={nm:'finite' for nm in METHODS},posterior_joint_mass={nm:np.nan for nm in POSTERIOR_METHODS})
            ci={nm:np.tile([.5,1.5],(3,1)) for nm in METHODS};commit_rep(db,1,x,ci,dg,true)
            for nm in METHODS:ci[nm][0]=[1.1,2.1]
            commit_rep(db,2,x,ci,dg,true)
            dg['mathematically_eligible']={nm:False for nm in METHODS};dg['status']={nm:'ineligible' for nm in METHODS}
            ci={nm:np.full((3,2),np.nan) for nm in METHODS};commit_rep(db,3,x,ci,dg,true)
            write_summary(db,dict(case_id=1,K=3),tmp,5000,.05,final=True,export=True);z=pd.read_csv(Path(tmp)/'summary.csv')
            np.testing.assert_allclose(z.CP_joint_conditional,.5);np.testing.assert_allclose(z.CP_joint_unconditional,1/3)
            np.testing.assert_allclose(z.CP_marginal_mean,5/9);np.testing.assert_allclose(z.AL_finite,1);np.testing.assert_allclose(z.MCSE_AL,0)
            self.assertTrue(z.ineligible_count.eq(1).all());db.close()
            db,n=open_db(tmp);self.assertEqual(n,3)
            # Exception inside a transaction cannot commit a partial attempt.
            try:
                with db:
                    db.execute('INSERT INTO rep VALUES (4,1,1,NULL)');raise RuntimeError('simulated interruption')
            except RuntimeError:pass
            self.assertEqual(db.execute('SELECT count(*) FROM rep').fetchone()[0],3);db.close()
    def test_large_finite_and_infinite(self):
        with tempfile.TemporaryDirectory() as tmp:
            db,_=open_db(tmp);x=[np.array([0,1,2,3])]*2
            dg=dict(positive=[3,3],fiducial_failed=0,mathematically_eligible={nm:True for nm in METHODS},status={nm:'finite' for nm in METHODS},posterior_joint_mass={})
            for r,length in enumerate([1e300,2e300,3e300],1):commit_rep(db,r,x,{nm:np.array([[0.,length]]) for nm in METHODS},dg,np.ones(1))
            write_summary(db,dict(case_id=1,K=2),tmp,5000,.05,True);z=pd.read_csv(Path(tmp)/'summary.csv');np.testing.assert_allclose(z.MCSE_AL,1e300/np.sqrt(3),rtol=1e-12)
            dg['status']={nm:'infinite_endpoints' for nm in METHODS};commit_rep(db,4,x,{nm:np.array([[0.,np.inf]]) for nm in METHODS},dg,np.ones(1))
            dg['status']={nm:'numerical_failure' for nm in METHODS};commit_rep(db,5,x,{nm:np.full((1,2),np.nan) for nm in METHODS},dg,np.ones(1))
            dg['status']={nm:'ineligible' for nm in METHODS};dg['mathematically_eligible']={nm:False for nm in METHODS};commit_rep(db,6,x,{nm:np.full((1,2),np.nan) for nm in METHODS},dg,np.ones(1))
            write_summary(db,dict(case_id=1,K=2),tmp,5000,.05,True);z=pd.read_csv(Path(tmp)/'summary.csv')
            for field in ['ineligible_count','numerical_failure_count','infinite_endpoint_count']:self.assertTrue(z[field].eq(1).all())
            self.assertTrue(z.finite_count.eq(3).all());db.close()

if __name__=='__main__':unittest.main(verbosity=2)
