"""Transactional per-replication SQLite storage, recoverable after interruption.
SQLite is authoritative; CSVs are regenerated atomically. No pickle loading.
"""
import csv,json,os,sqlite3
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm
from ziln_core import METHODS,POSTERIOR_METHODS,pairs_for,fit_ziln,logcv

SCHEMA='''
CREATE TABLE IF NOT EXISTS rep(rep INTEGER PRIMARY KEY, min_positive REAL, mean_positive REAL, fiducial_failed INTEGER);
CREATE TABLE IF NOT EXISTS family(rep INTEGER,method TEXT,status TEXT,eligible INTEGER,joint INTEGER,joint_defined INTEGER,defined INTEGER,finite INTEGER,AL REAL,posterior REAL,PRIMARY KEY(rep,method));
CREATE TABLE IF NOT EXISTS fit(rep INTEGER,population INTEGER,n INTEGER,zero INTEGER,positive INTEGER,mean_log REAL,variance_unbiased REAL,S REAL,CV REAL,PRIMARY KEY(rep,population));
CREATE TABLE IF NOT EXISTS pair(rep INTEGER,method TEXT,pair TEXT,true_ratio REAL,defined_family INTEGER,finite_family INTEGER,covered INTEGER,lower REAL,upper REAL,length REAL,PRIMARY KEY(rep,method,pair));
'''

def open_db(folder):
    db=sqlite3.connect(Path(folder)/'checkpoint.sqlite3',timeout=30)
    db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=FULL')
    db.executescript(SCHEMA)
    status=db.execute('PRAGMA quick_check').fetchone()[0]
    if status!='ok': raise RuntimeError('SQLite check failed: '+status)
    n,lo,hi=db.execute('SELECT count(*),min(rep),max(rep) FROM rep').fetchone()
    if n and (lo!=1 or hi!=n): raise RuntimeError('Non-contiguous committed replications')
    nf=db.execute('SELECT count(*) FROM family').fetchone()[0]
    if nf!=6*n: raise RuntimeError('Incomplete family records')
    return db,n

def commit_rep(db,r,x,ci,dg,true):
    ij=pairs_for(len(x));fam=[];pair=[];fits=[]
    for nm in METHODS:
        cc=ci[nm];defined=not np.isnan(cc).any();finite=defined and np.isfinite(cc).all()
        cov=(cc[:,0]<=true)&(cc[:,1]>=true) if defined else np.zeros(len(true),bool)
        # Scale before summation so mean of huge finite widths stays finite.
        widths=cc[:,1]-cc[:,0] if defined else np.full(len(true),np.nan)
        if finite:
            scale=float(np.max(widths));al=float(np.mean(widths/scale)*scale) if scale else 0.
        elif defined: al=float(np.mean(widths))
        else: al=None
        mass=dg['posterior_joint_mass'].get(nm,np.nan)
        fam.append((r,nm,dg['status'][nm],int(dg['mathematically_eligible'][nm]),int(finite and cov.all()),int(cov.all()),int(defined),int(finite),al,float(mass)))
        for j,(a,b) in enumerate(ij):
            pair.append((r,nm,f'{a+1}/{b+1}',float(true[j]),int(defined),int(finite),int(finite and cov[j]),float(cc[j,0]),float(cc[j,1]),float(widths[j]) if finite else None))
    for i,xx in enumerate(x):
        a=fit_ziln(xx)
        cv=float(np.exp(logcv(a['v'],a['p']))) if a['r']>=2 else None
        fits.append((r,i+1,a['n'],a['z'],a['r'],a['mu'],a['v'],a['S'],cv))
    with db:
        db.execute('INSERT INTO rep VALUES (?,?,?,?)',(r,min(dg['positive']),float(np.mean(dg['positive'])),dg['fiducial_failed']))
        db.executemany('INSERT INTO family VALUES (?,?,?,?,?,?,?,?,?,?)',fam)
        db.executemany('INSERT INTO pair VALUES (?,?,?,?,?,?,?,?,?,?)',pair)
        db.executemany('INSERT INTO fit VALUES (?,?,?,?,?,?,?,?,?)',fits)

def atomic_csv(df,path):
    path=Path(path);tmp=path.with_name(path.name+'.tmp')
    df.to_csv(tmp,index=False,na_rep='NA');os.replace(tmp,path)

def query_csv(db,query,path,header=None):
    path=Path(path);tmp=path.with_name(path.name+'.tmp');cur=db.execute(query)
    with tmp.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(header or [a[0] for a in cur.description])
        for row in cur: w.writerow(['NA' if a is None else a for a in row])
    os.replace(tmp,path)

def stable_mean_mcse(y):
    y=np.asarray(y,dtype=float);n=len(y)
    if not n: return np.nan,np.nan
    sc=float(np.max(np.abs(y)))
    if sc==0:return 0.,0. if n>1 else np.nan
    yy=y/sc
    return float(yy.mean()*sc),float(yy.std(ddof=1)/np.sqrt(n)*sc) if n>1 else np.nan

def wilson(success,n):
    if not n:return np.nan,np.nan
    p=success/n;z=norm.ppf(.975);den=1+z*z/n
    center=(p+z*z/(2*n))/den;half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half

def write_summary(db,cfg,folder,B,alpha,final=False,export=False):
    data=pd.read_sql_query('SELECT * FROM family ORDER BY rep,method',db)
    rr=pd.read_sql_query('SELECT * FROM rep ORDER BY rep',db);n=len(rr)
    if not n:return
    finite=data.pivot(index='rep',columns='method',values='finite').reindex(columns=METHODS)
    common_ids=finite.index[finite.eq(1).all(axis=1)];cn=len(common_ids)
    marginal=pd.read_sql_query('SELECT method,pair,sum(covered) hits FROM pair GROUP BY method,pair',db)
    rows=[]
    for nm in METHODS:
        d=data[data.method==nm];nf=int(d.finite.sum());s=int(d.joint.sum());cp=s/n;cpc=s/nf if nf else np.nan
        lo,hi=wilson(s,n);clo,chi=wilson(s,nf)
        y=d.loc[d.finite.eq(1),'AL'].to_numpy();mean,se=stable_mean_mcse(y)
        common=d[d.rep.isin(common_ids)];cmean,cse=stable_mean_mcse(common.AL.to_numpy());ccp=common.joint.sum()/cn if cn else np.nan
        pm=d.posterior.dropna();elig=int(d.eligible.sum());num=int(d.status.eq('numerical_failure').sum());inf=int(d.status.eq('infinite_endpoints').sum())
        failed_draws=rr.fiducial_failed.dropna()
        row=dict(cfg,method=nm,replications_completed=n,CP_joint_unconditional=cp,MCSE_CP=np.sqrt(cp*(1-cp)/n),CP_MC95_lower=lo,CP_MC95_upper=hi,CP_nominal_within_MC95=bool(lo<=1-alpha<=hi),
          CP_joint_conditional=cpc,MCSE_CP_conditional=np.sqrt(cpc*(1-cpc)/nf) if nf else np.nan,CP_cond_MC95_lower=clo,CP_cond_MC95_upper=chi,CP_cond_nominal_within_MC95=bool(clo<=1-alpha<=chi) if nf else None,
          eligible_count=elig,eligibility_rate=elig/n,ineligible_count=n-elig,ineligible_rate=1-elig/n,numerical_failure_count=num,numerical_failure_rate=num/n,infinite_endpoint_count=inf,infinite_endpoint_rate=inf/n,
          finite_rate=nf/n,CP_joint_including_uninformative=d.joint_defined.sum()/n,CP_marginal_mean=marginal.loc[marginal.method.eq(nm),'hits'].mean()/n,undefined_rate=1-d.defined.sum()/n,failure_rate=1-nf/n,uninformative_rate=inf/n,finite_count=nf,
          posterior_joint_mass_mean=pm.mean() if len(pm) else np.nan,posterior_validation_families=len(pm),AL_finite=mean,MCSE_AL=se,common_finite_count=cn,CP_common=ccp,AL_common=cmean,MCSE_CP_common=np.sqrt(ccp*(1-ccp)/cn) if cn else np.nan,MCSE_AL_common=cse,
          mean_min_positive=rr.min_positive.mean(),mean_positive=rr.mean_positive.mean(),fiducial_nonfinite_draw_rate=failed_draws.sum()/(len(failed_draws)*B) if len(failed_draws) else np.nan,
          AL_median=float(np.median(y)) if final and nf else np.nan,AL_q95=float(np.quantile(y,.95,method='linear')) if final and nf else np.nan,length_quantile_records=nf if final else 0,length_quantiles_complete=bool(final))
        rows.append(row)
    atomic_csv(pd.DataFrame(rows),Path(folder)/'summary.csv')
    nfmap={r['method']:r['finite_count'] for r in rows}
    marginal['case_id']=cfg['case_id'];marginal['attempts']=n;marginal['finite_families']=marginal.method.map(nfmap)
    marginal['CP_marginal_unconditional']=marginal.hits/n
    marginal['CP_marginal_conditional']=marginal.hits/marginal.finite_families.replace(0,np.nan)
    atomic_csv(marginal.drop(columns='hits')[['case_id','method','pair','attempts','finite_families','CP_marginal_unconditional','CP_marginal_conditional']],Path(folder)/'marginal_summary.csv')
    if export: export_logs(db,folder,B)

def export_logs(db,folder,B):
    folder=Path(folder)
    ff=pd.read_sql_query('SELECT * FROM family ORDER BY rep,method',db);rr=pd.read_sql_query('SELECT * FROM rep ORDER BY rep',db).set_index('rep')
    fields=[('joint','joint'),('defined','defined'),('finite','finite'),('AL','AL'),('eligible','eligible')]
    cols={}
    for prefix,field in fields:
        for nm in METHODS:cols[prefix+'_'+nm]=ff[ff.method.eq(nm)].set_index('rep')[field]
    for status in ['numerical_failure','infinite_endpoints']:
        for nm in METHODS:cols[('infinite_endpoint' if status=='infinite_endpoints' else status)+'_'+nm]=ff[ff.method.eq(nm)].set_index('rep').status.eq(status).astype(int)
    logs=pd.DataFrame(cols).join(rr).reset_index()
    atomic_csv(logs,folder/'replication_log.csv')
    query_csv(db,'SELECT * FROM fit ORDER BY rep,population',folder/'data_fit_log.csv')
    query_csv(db,'SELECT * FROM pair ORDER BY rep,method,pair',folder/'pairwise_log.csv')
    pp=ff[ff.method.isin(POSTERIOR_METHODS)][['rep','method','posterior']].rename(columns={'posterior':'joint_posterior_mass'})
    pp['joint_posterior_mass']=pd.to_numeric(pp['joint_posterior_mass'],errors='coerce')
    pp['validation_draws']=B;pp['MCSE_mass']=np.sqrt(pp.joint_posterior_mass*(1-pp.joint_posterior_mass)/B)
    atomic_csv(pp[['rep','method','validation_draws','joint_posterior_mass','MCSE_mass']],folder/'posterior_validation_log.csv')
