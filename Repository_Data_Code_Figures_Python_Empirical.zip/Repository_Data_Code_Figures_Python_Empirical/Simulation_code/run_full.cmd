@echo off
setlocal
cd /d "%~dp0"
.venv\Scripts\python.exe run_revision.py --mode full --reps 10000 --draws 5000 --seed 20261003 --out results_full
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe reviewer_evidence.py results_full
if errorlevel 1 exit /b 1
echo Full simulation finished. Open results_full\reviewer_completeness.csv.
