import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
from ziln_core import METHODS
from checkpoint import atomic_csv

def make_evidence(folder):
    out=Path(folder);s=json.loads((out/'run_settings.json').read_text());grid=pd.read_csv(out/'grid.csv');checks=[];rows=[]
    for g in grid.case_id:
        p=out/f'case_{g:03d}'/'summary.csv';z=pd.read_csv(p) if p.exists() else None
        complete=z is not None and len(z)==6 and set(z.method)==set(METHODS) and z.replications_completed.eq(s['R']).all()
        checks.append(dict(case_id=g,summary_present=z is not None,complete=bool(complete)))
        if z is not None:rows.append(z)
    atomic_csv(pd.DataFrame(checks),out/'reviewer_completeness.csv')
    if not rows:return
    z=pd.concat(rows,ignore_index=True);atomic_csv(z,out/'simulation_summary.csv')
    z['coverage_assessment']=np.select([z.CP_cond_MC95_lower.isna(),z.CP_cond_MC95_upper<1-s['alpha'],z.CP_cond_MC95_lower>1-s['alpha']],['unavailable','below_nominal','above_nominal'],default='MC_interval_includes_nominal')
    atomic_csv(z,out/'reviewer_coverage_and_length.csv');prior=[]
    for g in z.case_id.unique():
        for typ in ['ETI','HPD']:
            a=z[(z.case_id==g)&(z.method==typ+'_IndJ')].iloc[0];b=z[(z.case_id==g)&(z.method==typ+'_Uniform')].iloc[0]
            prior.append(dict(case_id=g,type=typ,CP_cond_IndJ=a.CP_joint_conditional,CP_cond_Uniform=b.CP_joint_conditional,finite_IndJ=a.finite_count,finite_Uniform=b.finite_count,CP_common_IndJ=a.CP_common,CP_common_Uniform=b.CP_common,AL_common_IndJ=a.AL_common,AL_common_Uniform=b.AL_common,common_finite_count=a.common_finite_count))
    atomic_csv(pd.DataFrame(prior),out/'reviewer_prior_sensitivity.csv')
    # Paired scale check: identical seed_case and designs except mu.
    scale=[]
    for _,a in grid[grid.label.eq('scale_check')].iterrows():
        base=int(a.seed_case);left=z[z.case_id.eq(base)].set_index('method');right=z[z.case_id.eq(a.case_id)].set_index('method')
        if len(left)!=6 or len(right)!=6:continue
        for nm in METHODS:
            aa=left.loc[nm];bb=right.loc[nm]
            scale.append(dict(case_id=a.case_id,base_case=base,method=nm,CP_cond_difference=bb.CP_joint_conditional-aa.CP_joint_conditional,AL_finite_difference=bb.AL_finite-aa.AL_finite,finite_count_difference=bb.finite_count-aa.finite_count))
    if scale:atomic_csv(pd.DataFrame(scale),out/'reviewer_scale_invariance.csv')
    if s['R']!=10000 or s['B']!=5000:print('TEST settings: final study requires R=10000, B=5000.')
    print(f'Evidence: {sum(c["complete"] for c in checks)}/{len(checks)} scenarios complete.')

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python reviewer_evidence.py RESULTS_FOLDER')
    make_evidence(sys.argv[1])
