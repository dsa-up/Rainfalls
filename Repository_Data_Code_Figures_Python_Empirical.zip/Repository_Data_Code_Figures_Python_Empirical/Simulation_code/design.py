import numpy as np

def make_design(mode,K=3,n=25,delta=.2,v=.5):
    design=[]
    grid=[(k,nn,d,vv) for vv in [.5,1,2] for d in [.2,.5,.8,.9] for nn in [25,50,100] for k in [3,5,10]] if mode=='full' else [(K,n,delta,v)]
    for k,nn,d,vv in grid:
        design.append(dict(label='homogeneous',K=k,n=[nn]*k,delta=[d]*k,v=[vv]*k,mu=[0.]*k))
    if mode=='full':
        for k in [3,5,10]:
            for profile in ['aligned','reverse_v','n_only','delta_only','v_only','severe_zero']:
                nn=np.resize([25,50,100],k).tolist();dd=np.resize([.2,.5,.8],k).tolist();vv=np.resize([.5,1,2],k).tolist()
                if profile=='reverse_v': vv=np.resize([2,1,.5],k).tolist()
                if profile=='n_only': dd=[.5]*k;vv=[1.]*k
                if profile=='delta_only': nn=[50]*k;vv=[1.]*k
                if profile=='v_only': nn=[50]*k;dd=[.5]*k
                if profile=='severe_zero': dd=np.resize([.2,.8,.9],k).tolist()
                design.append(dict(label=profile,K=k,n=nn,delta=dd,v=vv,mu=[0.]*k))
        for k in [3,5,10]:
            idx=next(i for i,a in enumerate(design) if a['label']=='aligned' and a['K']==k)
            a=dict(design[idx]);a.update(label='scale_check',mu=np.log(np.arange(1,k+1)+1).tolist(),seed_case=idx+1);design.append(a)
    for i,a in enumerate(design): a.setdefault('seed_case',i+1)
    return design

def design_table(design):
    return [dict(case_id=i+1,**{k:(';'.join(format(x,'.15g') for x in v) if isinstance(v,list) else v) for k,v in a.items()}) for i,a in enumerate(design)]
