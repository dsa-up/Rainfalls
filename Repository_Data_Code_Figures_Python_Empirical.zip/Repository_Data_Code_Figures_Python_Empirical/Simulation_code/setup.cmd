@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3.14 --version >nul 2>nul
if errorlevel 1 goto usepython
py -3.14 -m venv .venv
if errorlevel 1 goto fail
goto install
:usepython
where python >nul 2>nul
if errorlevel 1 goto nopython
python -c "import sys; assert sys.version_info[:3] == (3,14,7), 'Please install Python 3.14.7 (64-bit), then rerun setup.cmd'"
if errorlevel 1 goto fail
python -m venv .venv
if errorlevel 1 goto fail
:install
.venv\Scripts\python.exe -c "import sys; assert sys.version_info[:3] == (3,14,7), 'This tested setup requires Python 3.14.7'"
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements-tested.txt
if errorlevel 1 goto fail
.venv\Scripts\python.exe check_simulation_theory.py
if errorlevel 1 goto fail
echo Setup and theory checks completed.
exit /b 0
:nopython
echo Python not found. Install Python 3.14.7 64-bit with Add python.exe to PATH selected.
exit /b 1
:fail
echo Setup failed. Read the error above before running simulations.
exit /b 1
