#!/usr/bin/env python
"""Windows-compatible CLI. Each attempted dataset commits one SQLite transaction."""
import argparse,hashlib,json,os,platform,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
from scipy.stats import binom
from ziln_core import METHODS,fit_ziln,logcv,pairs_for,seed_key,rng_for,generate,intervals
from design import make_design,design_table
from checkpoint import open_db,commit_rep,write_summary,atomic_csv

HOME=Path(__file__).resolve().parent

def parser():
    p=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    p.add_argument('--mode',choices=['smoke','simulation','full','rainfall'],default='smoke')
    p.add_argument('--out');p.add_argument('--draws',type=int,default=5000);p.add_argument('--reps',type=int)
    p.add_argument('--seed',type=int,default=20261003);p.add_argument('--alpha',type=float,default=.05)
    p.add_argument('--K',type=int,default=3);p.add_argument('--n',type=int,default=25)
    p.add_argument('--delta',type=float,default=.2);p.add_argument('--variance',type=float,default=.5)
    p.add_argument('--start-case',type=int,default=1);p.add_argument('--end-case',type=int)
    p.add_argument('--stop-after',type=int);p.add_argument('--unlock',choices=['no','yes'],default='no')
    p.add_argument('--data',default=str(HOME/'data_rainfalls_NE.csv'))
    p.add_argument('--summary-every',type=int,default=100,help='CSV snapshot frequency; database commits EVERY attempt')
    return p

def atomic_json(obj,path):
    tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8');os.replace(tmp,path)

def hashes():
    return {n:hashlib.sha256((HOME/n).read_bytes()).hexdigest() for n in ['run_revision.py','ziln_core.py','checkpoint.py','design.py']}

def main(argv=None):
    a=parser().parse_args(argv);R=a.reps if a.reps is not None else (10000 if a.mode=='full' else 20)
    if not (100<=a.draws and 2<=R<=100000 and 0<=a.seed<=2147483646 and 0<a.alpha<1 and a.summary_every>=1):raise ValueError('Invalid draws/reps/seed/alpha/summary-every')
    if a.stop_after is not None and a.stop_after<1:raise ValueError('--stop-after must be positive')
    if not (2<=a.K<=100 and a.n>=2 and 0<a.delta<1 and a.variance>0 and np.isfinite(a.variance)): raise ValueError('Invalid scenario')
    out=Path(a.out or 'results_'+a.mode);out.mkdir(parents=True,exist_ok=True);lock=out/'RUNNING.lock'
    if lock.exists():
        if a.unlock!='yes':raise RuntimeError('Output locked. Only after the previous process has STOPPED, rerun with --unlock yes.')
        lock.unlink()
    # Exclusive create on Windows and POSIX. Never unlock an active process.
    fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL)
    with os.fdopen(fd,'w') as f:f.write(f'PID={os.getpid()}\n{time.ctime()}\n')
    active=None
    try:
        settings=dict(schema=1,mode=a.mode,R=R,B=a.draws,alpha=a.alpha,seed=a.seed,methods=list(METHODS),rng='PCG64DXSM',python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,pandas=pd.__version__,code=hashes())
        if a.mode=='rainfall':settings['data_sha256']=hashlib.sha256(Path(a.data).read_bytes()).hexdigest()
        else:settings['design']=make_design(a.mode,a.K,a.n,a.delta,a.variance)
        manifest=out/'run_settings.json'
        if manifest.exists():
            if json.loads(manifest.read_text(encoding='utf-8'))!=settings:raise RuntimeError('Settings/code/dependencies changed. Use original settings or a NEW --out folder.')
        else:
            if list(out.glob('case_*/checkpoint.sqlite3')):raise RuntimeError('Existing checkpoints without run_settings.json; restore original manifest')
            atomic_json(settings,manifest)
        (out/'sessionInfo.txt').write_text(sys.version+'\n'+platform.platform()+'\n'+json.dumps({k:settings[k] for k in ['numpy','scipy','pandas','rng']},indent=2),encoding='utf-8')
        def progress(msg):
            line=time.strftime('%Y-%m-%d %H:%M:%S')+' '+msg;print(line,flush=True)
            with (out/'progress.log').open('a',encoding='utf-8') as f:f.write(line+'\n')
        if a.mode=='rainfall':
            rainfall(a,out);return
        design=settings['design'];grid=design_table(design);last=a.end_case or len(design)
        if not 1<=a.start_case<=last<=len(design):raise ValueError('Invalid case range')
        atomic_csv(pd.DataFrame(grid),out/'grid.csv')
        atomic_csv(pd.DataFrame([dict(mode=a.mode,outer_attempts=R,inner_draws=a.draws,alpha=a.alpha,seed=a.seed,design='fixed_attempts_no_replacement',primary_CP='CP_joint_conditional',primary_AL='AL_finite')]),out/'run_metadata.csv')
        eligibility=[]
        for g,case in enumerate(design,1):
            for nm in METHODS:
                t=4 if 'Uniform' in nm else 2;pr=float(np.prod(binom.sf(t-1,case['n'],1-np.array(case['delta']))))
                eligibility.append(dict(case_id=g,K=case['K'],method=nm,minimum_positive=t,theoretical_eligibility=pr,expected_eligible=R*pr))
        atomic_csv(pd.DataFrame(eligibility),out/'theoretical_eligibility.csv')
        executed=0
        for g in range(a.start_case,last+1):
            c=design[g-1];cfg=grid[g-1];folder=out/f'case_{g:03d}';folder.mkdir(exist_ok=True)
            ij=pairs_for(c['K']);cv=np.exp(logcv(np.array(c['v']),1-np.array(c['delta'])));true=cv[ij[:,0]]/cv[ij[:,1]]
            atomic_csv(pd.DataFrame(dict(population=np.arange(1,c['K']+1),n=c['n'],delta=c['delta'],v=c['v'],mu=c['mu'],CV=cv)),folder/'parameters.csv')
            atomic_csv(pd.DataFrame(dict(pair=[f'{i+1}/{j+1}' for i,j in ij],true_ratio=true)),folder/'true_ratios.csv')
            db,done=open_db(folder);active=(db,cfg,folder)
            if done>R:raise RuntimeError('Checkpoint exceeds requested R')
            if done>=R:
                write_summary(db,cfg,folder,a.draws,a.alpha,final=True,export=True);db.close();active=None
                progress(f'Case {g} complete; skipped {done} attempts.');continue
            progress(f'Case {g}/{len(design)}: starting/resuming attempt {done+1}/{R}')
            for r in range(done+1,R+1):
                rng=rng_for(seed_key(a.seed,c['seed_case'],r,0))
                x=[generate(c['n'][i],c['delta'][i],c['mu'][i],c['v'][i],rng) for i in range(c['K'])]
                seeds=[seed_key(a.seed,c['seed_case'],r,s) for s in range(1,7)]
                ci,dg=intervals(x,a.draws,a.alpha,seeds)
                commit_rep(db,r,x,ci,dg,true);executed+=1
                stopping=a.stop_after is not None and executed>=a.stop_after
                if r%a.summary_every==0 or r==R or stopping:
                    write_summary(db,cfg,folder,a.draws,a.alpha,final=(r==R),export=(r==R or stopping))
                    progress(f'Case {g}: saved attempt {r}/{R}')
                if stopping:
                    db.close();active=None;evidence(out);progress('Stopped after requested NEW attempts; resume with same settings.');return
            db.close();active=None
        evidence(out);progress('Finished requested case range. Completed attempts are skipped on rerun.')
    except KeyboardInterrupt:
        print('\nInterrupted; committed attempts are safe. Rerun the same command.',flush=True)
        if active:
            db,cfg,folder=active
            write_summary(db,cfg,folder,a.draws,a.alpha,export=True);db.close();active=None
        if (out/'grid.csv').exists():evidence(out)
        raise SystemExit(130)
    finally:
        if active:active[0].close()
        lock.unlink(missing_ok=True)

def rainfall(a,out):
    dat=pd.read_csv(a.data,encoding='utf-8-sig')
    if 'date' not in dat:raise ValueError('CSV requires date column')
    dt=pd.to_datetime(dat.date,format='%d/%m/%Y',errors='raise')
    if dt.duplicated().any() or dt.isna().any():raise ValueError('Invalid/duplicate date')
    names=[n for n in dat if n!='date'];x=[dat[n].to_numpy(dtype=float) for n in names]
    if len(x)<2:raise ValueError('At least two province columns required')
    fitted=[fit_ziln(xx) for xx in x];ci,dg=intervals(x,a.draws,a.alpha,[seed_key(a.seed,900,1,s) for s in range(1,7)])
    rows=[dict(province=nm,n=f['n'],positive=f['r'],delta=1-f['p'],mu=f['mu'],variance_unbiased=f['v'],variance_MLE=f['S']/f['r'] if f['r'] else np.nan,CV=float(np.exp(logcv(f['v'],f['p'])))) for nm,f in zip(names,fitted)]
    atomic_csv(pd.DataFrame(rows),out/'rainfall_summary.csv');ij=pairs_for(len(x));ints=[]
    for nm in METHODS:
        for j,(i,k) in enumerate(ij):ints.append(dict(method=nm,pair=names[i]+'/'+names[k],estimate=rows[i]['CV']/rows[k]['CV'],lower=ci[nm][j,0],upper=ci[nm][j,1],status=dg['status'][nm]))
    atomic_csv(pd.DataFrame(ints),out/'rainfall_intervals.csv')
    atomic_csv(pd.DataFrame([dict(method=nm,validation_draws=a.draws,joint_posterior_mass=mass) for nm,mass in dg['posterior_joint_mass'].items()]),out/'posterior_validation.csv')
    print('Rainfall intervals saved. This mode reproduces the supplied interval analysis; it does not run AD/seasonal/block sensitivity checks.')

def evidence(out):
    from reviewer_evidence import make_evidence
    make_evidence(out)

if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,FileNotFoundError) as exc:print('ERROR:',exc,file=sys.stderr);raise SystemExit(2)
