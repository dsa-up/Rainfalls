@echo off
setlocal
cd /d "%~dp0"
.venv\Scripts\python.exe check_simulation_theory.py
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe run_revision.py --mode full --reps 20 --draws 5000 --seed 20261003 --out results_test_all129
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe reviewer_evidence.py results_test_all129
if errorlevel 1 exit /b 1
echo Test finished. Open results_test_all129\reviewer_completeness.csv. All 129 complete flags should be True.
