import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ziln_core import METHODS

def main(folder):
    out=Path(folder);z=pd.read_csv(out/'simulation_summary.csv');z=z[z.label.eq('homogeneous')].copy()
    for dst,src in [('n_scalar','n'),('delta_scalar','delta'),('v_scalar','v')]:z[dst]=z[src].astype(str).str.split(';').str[0].astype(float)
    figs=out/'figures';figs.mkdir(exist_ok=True);captions=[]
    cols=['#0072B2','#E69F00','#009E73','#CC79A7','#D55E00','#000000']
    titles={'CP_joint_conditional':'Joint coverage among finite families','CP_joint_unconditional':'Operational joint success among all attempts','AL_finite':'Mean length among finite families','failure_rate':'Proportion without a finite family','AL_common':'Mean length on the common finite subset'}
    for k in [3,5,10]:
        dat=z[z.K.eq(k)]
        if dat.empty:continue
        for metric,title in titles.items():
            name=f'{metric}_K{k}';dat.to_csv(figs/(name+'_source.csv'),index=False);fig,axes=plt.subplots(3,4,figsize=(13,9),squeeze=False)
            for i,n in enumerate([25,50,100]):
                for j,delta in enumerate([.2,.5,.8,.9]):
                    ax=axes[i,j];d=dat[dat.n_scalar.eq(n)&np.isclose(dat.delta_scalar,delta)]
                    for nm,color in zip(METHODS,cols):
                        a=d[d.method.eq(nm)].sort_values('v_scalar');yy=a[metric].to_numpy(dtype=float)
                        if metric.startswith('AL_'):
                            with np.errstate(all='ignore'):yy=np.where(np.isfinite(yy)&(yy>0),np.log10(yy),np.nan)
                        ax.plot(a.v_scalar,yy,'o-',label=nm,color=color,markersize=3)
                    if metric.startswith('CP_'):ax.axhline(.95,color='gray',ls='--',lw=.8)
                    if not metric.startswith('AL_'):ax.set_ylim(0,1.01)
                    ax.set_xticks([.5,1,2]);ax.set_title(f'n={n}, zero probability={delta}',fontsize=9);ax.set_xlabel('Log-positive variance');ax.set_ylabel('log10 mean length' if metric.startswith('AL_') else 'Probability')
            handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=6);fig.suptitle(f'{title}, K={k}');fig.tight_layout(rect=(0,.04,1,.96));fig.savefig(figs/(name+'.svg'));fig.savefig(figs/(name+'.png'),dpi=200);plt.close(fig)
            captions.append(dict(file=name+'.svg',K=k,metric=metric,description=title+'. Missing estimates remain gaps; inspect finite/common counts. Length axes use log10. The 0.95 line is a reference, not proof of calibration.'))
    pd.DataFrame(captions).to_csv(figs/'figure_captions.csv',index=False)
if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python make_simulation_figures.py RESULTS_FOLDER')
    main(sys.argv[1])
