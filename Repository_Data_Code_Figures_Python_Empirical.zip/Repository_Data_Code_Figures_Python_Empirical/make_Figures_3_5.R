#!/usr/bin/env Rscript
# Base R only. Run: Rscript make_Figures_3_5.R simulation_summary.csv figures
# No simulations are rerun. Never replace missing values with zero.
args <- commandArgs(trailingOnly=TRUE)
input <- if(length(args)>=1) args[1] else 'simulation_summary.csv'
out <- if(length(args)>=2) args[2] else 'figures'
dir.create(out,recursive=TRUE,showWarnings=FALSE)
d <- read.csv(input,na.strings=c('NA',''),check.names=FALSE)
methods <- c('GCI','ETI_IndJ','ETI_Uniform','HPD_IndJ','HPD_Uniform','FGCI')
labels <- c('GCI','ETI-Ind.J','ETI-Uniform','HPDI-Ind.J','HPDI-Uniform','FGCI')
colors <- c('#F04B4B','#999900','#00A878','#1599E5','#CE43DC','#333333')
stopifnot(nrow(d)==774, !anyDuplicated(d[c('case_id','method')]),
          all(d$replications_completed==10000),all(d$method %in% methods))
h <- d[d$label=='homogeneous',]
first <- function(x) as.numeric(sub(';.*','',x))
h$n0 <- first(h$n); h$delta0 <- first(h$delta); h$v0 <- first(h$v)
stopifnot(nrow(h)==648)
draw <- function(k) {
  par(mfrow=c(6,4),mar=c(2.3,2.9,1.8,.5),oma=c(6.0,1.2,2.0,.3),
      mgp=c(1.8,.55,0),tcl=-.2,cex=.72,family='serif',xaxs='i',yaxs='i')
  for(n in c(25,50,100)) for(metric in c('CP_joint_conditional','AL_finite')) {
    for(delta in c(.2,.5,.8,.9)) {
      z <- h[h$K==k & h$n0==n & abs(h$delta0-delta)<1e-8,]
      if(metric=='CP_joint_conditional') {
        ylim <- c(.8,1)
      } else {
        a <- log10(z$AL_finite[is.finite(z$AL_finite) & z$AL_finite>0])
        if(length(a)) { rr <- range(a); pad <- max(diff(rr),.2)*.08; ylim <- rr+c(-pad,pad) }
        else ylim <- c(0,1)
      }
      plot(NA,xlim=c(.8,3.2),ylim=ylim,xaxt='n',xlab='',ylab='',bty='o')
      abline(h=if(metric=='CP_joint_conditional') seq(.8,1,.05) else pretty(ylim,n=4),col='#E5E5E5')
      axis(1,at=1:3,labels=c('0.5','1','2'))
      if(metric=='CP_joint_conditional') abline(h=.95,lty=2,lwd=1.1)
      for(j in seq_along(methods)) {
        a <- z[z$method==methods[j],]; a <- a[order(a$v0),]
        stopifnot(nrow(a)==3)
        y <- a[[metric]]
        if(metric=='AL_finite') {stopifnot(all(y[is.finite(y)]>0));y <- log10(y)}
        lines(1:3,y,col=colors[j],lty=if(j==6) 3 else 1,lwd=1.15)
        points(1:3,y,col=colors[j],pch=ifelse(a$finite_count<100,1,16),cex=.65)
      }
      title(main=bquote(n==.(n)~','~delta==.(delta)),cex.main=.9)
      mtext(expression(sigma^2),side=1,line=1.35,cex=.65)
      if(delta==.2) mtext(if(metric=='CP_joint_conditional') 'Conditional joint CP' else expression(log[10](AL[finite])),side=2,line=2,cex=.7)
    }
  }
  mtext(bquote('All pairwise CV ratios: ' ~ k==.(k)),outer=TRUE,side=3,line=.4,cex=1)
  par(mfrow=c(1,1),fig=c(0,1,0,1),new=TRUE,mar=c(0,0,0,0),oma=c(0,0,0,0),xpd=NA,cex=.85)
  plot.new();plot.window(c(0,1),c(0,1),xaxs='i',yaxs='i')
  legend(.5,.055,xjust=.5,yjust=.5,legend=labels,col=colors,lty=c(1,1,1,1,1,3),
         pch=16,ncol=6,bty='n',cex=.78)
  text(.5,.018,'CP axes are shared; AL axes vary by panel. Hollow points: finite n < 100. Missing estimates are not plotted.',cex=.64)
}
for(k in c(3,5,10)) {
  number <- match(k,c(3,5,10))+2
  png(file.path(out,paste0('Figure',number,'.png')),width=10,height=12,units='in',res=300)
  draw(k);dev.off()
  pdf(file.path(out,paste0('Figure',number,'.pdf')),width=10,height=12,useDingbats=FALSE)
  draw(k);dev.off()
}
write.csv(h,file.path(out,'figure_data.csv'),row.names=FALSE,na='NA')
capture.output(sessionInfo(),file=file.path(out,'plot_sessionInfo.txt'))
