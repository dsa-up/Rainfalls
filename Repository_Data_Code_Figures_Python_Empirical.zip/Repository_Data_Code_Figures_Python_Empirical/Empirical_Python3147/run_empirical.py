"""Complete rainfall empirical analysis; formula port of the supplied R driver.
Python PCG64DXSM streams differ from R's Mersenne-Twister streams.
No failed dataset or bootstrap sample is replaced. No interval draws are pooled.
"""
from pathlib import Path
import argparse,hashlib,json,sys,platform
import numpy as np
import pandas as pd
import scipy
from scipy import stats,special,optimize
from ziln_core import METHODS,POSTERIOR_METHODS,fit_ziln,logcv,pairs_for,intervals,seed_key,rng_for

def gamma_fit(y):
    if len(y)<2 or not np.isfinite(y).all() or (y<=0).any():raise ValueError('Invalid positive gamma sample')
    mean=y.mean();s=np.log(mean)-np.log(y).mean()
    if not s>0:raise ValueError('Degenerate gamma sample')
    a=optimize.brentq(lambda a:np.log(a)-special.digamma(a)-s,1e-7,1e9,xtol=1e-9)
    return a,mean/a

def positive_fit(y,model):
    if model=='LN':
        mu=np.log(y).mean();sd=np.log(y).std(ddof=0);par=(mu,sd);dist=stats.lognorm(s=sd,scale=np.exp(mu));k=2
    elif model=='Gamma':
        shape,scale=gamma_fit(y);par=(shape,scale);dist=stats.gamma(a=shape,scale=scale);k=2
    elif model=='Exponential':par=(1/y.mean(),);dist=stats.expon(scale=y.mean());k=1
    elif model=='Normal':par=(y.mean(),y.std(ddof=0));dist=stats.norm(*par);k=2
    else:raise ValueError(model)
    ll=float(dist.logpdf(y).sum())
    return dict(model=model,par=par,dist=dist,ll=ll,AIC=-2*ll+2*k,BIC=-2*ll+k*np.log(len(y)))

def ad_stat(y,f):
    u=np.clip(f['dist'].cdf(np.sort(y)),1e-15,1-1e-15);n=len(u)
    return float(-n-np.mean((2*np.arange(1,n+1)-1)*(np.log(u)+np.log1p(-u[::-1]))))

def ad_bootstrap(y,model,B,seed):
    rng=rng_for(seed);f=positive_fit(y,model);obs=ad_stat(y,f);v=np.full(B,np.nan)
    for b in range(B):
        par=f['par'];yy=rng.lognormal(par[0],par[1],len(y)) if model=='LN' else rng.gamma(par[0],par[1],len(y))
        try:v[b]=ad_stat(yy,positive_fit(yy,model))
        except (ValueError,FloatingPointError,RuntimeError):pass
    good=np.isfinite(v);exceed=int((v[good]>=obs).sum());p=(1+exceed)/(B+1) if good.all() else np.nan
    return dict(model=model,AD=obs,bootstrap_attempts=B,finite_count=int(good.sum()),failures=int((~good).sum()),exceedances=exceed,p_value=p,MCSE=np.sqrt(p*(1-p)/B)),v

def interval_table(x,names,ci,label):
    f=[fit_ziln(a) for a in x.T];cv=np.exp([logcv(a['v'],a['p']) for a in f]);ij=pairs_for(len(f));rows=[]
    for m in METHODS:
        for j,(a,b) in enumerate(ij):
            lo,hi=ci[m][j];rows.append(dict(subset=label,method=m,pair=names[a]+'/'+names[b],estimate=cv[a]/cv[b],lower=lo,upper=hi,width=hi-lo,excludes_one=bool(lo>1 or hi<1)))
    return pd.DataFrame(rows)

def construct(x,B,seed,case,rep=1):
    return intervals(list(x.T),B,.05,[seed_key(seed,case,rep,s) for s in range(1,7)])

def describe(x,names,season=None):
    rows=[]
    for name,y in zip(names,x.T):
        a=fit_ziln(y);r=dict(province=name,n=a['n'],zero=a['z'],positive=a['r'],delta=1-a['p'],mu=a['mu'],variance_unbiased=a['v'],variance_MLE=a['S']/a['r'],CV=float(np.exp(logcv(a['v'],a['p']))))
        if season:r['season']=season
        rows.append(r)
    return pd.DataFrame(rows)

def cv_logs(x,model):
    f=[fit_ziln(a) for a in x.T]
    if any(a['r']<2 or not np.isfinite(a['S']) or a['S']<=0 for a in f):return np.full(x.shape[1],np.nan)
    if model=='LN':return np.array([logcv(a['v'],a['p']) for a in f])
    return np.array([.5*np.log((1+1/gamma_fit(y[y>0])[0])/a['p']-1) for y,a in zip(x.T,f)])

def block_plan(dates,L,stratified):
    season=np.where(np.isin(dates.month,np.arange(5,11)),'wet','dry');keys=np.array([str(y)+'_'+s for y,s in zip(dates.year,season)])
    groups=[np.flatnonzero(keys==k) for k in sorted(set(keys))] if stratified else [np.arange(len(dates))]
    day=dates.to_numpy().astype('datetime64[D]').astype(np.int64);plan=[]
    for ii in groups:
        ll=min(L,len(ii));starts=np.arange(len(ii)-ll+1);starts=starts[day[ii[starts+ll-1]]-day[ii[starts]]==ll-1]
        if not len(starts):raise ValueError('No consecutive blocks; shorten block length or review dates')
        plan.append((ii,ll,starts))
    return plan

def draw_blocks(plan,rng):
    chunks=[]
    for ii,ll,starts in plan:
        chosen=rng.choice(starts,size=int(np.ceil(len(ii)/ll)),replace=True)
        chunks.append(ii[(chosen[:,None]+np.arange(ll)).ravel()][:len(ii)])
    return np.concatenate(chunks)

def block_compare(x,names,dates,L,B,seed,stratified):
    rng=rng_for(seed);plan=block_plan(dates,L,stratified);ij=pairs_for(x.shape[1]);models=['LN','Gamma'];draws={md:np.full((B,len(ij)),np.nan) for md in models};obs={}
    for md in models:
        lc=cv_logs(x,md);obs[md]=lc[ij[:,0]]-lc[ij[:,1]]
    for b in range(B):
        xx=x[draw_blocks(plan,rng)]
        for md in models:
            try:
                lc=cv_logs(xx,md);draws[md][b]=lc[ij[:,0]]-lc[ij[:,1]]
            except (ValueError,FloatingPointError,RuntimeError):pass
    rows=[]
    for md,mat in draws.items():
        good=np.isfinite(mat).all(axis=1);cnt=int(good.sum());se=np.full(len(ij),np.nan);crit=np.nan
        if cnt>=2:
            se=mat[good].std(axis=0,ddof=1)
            if np.isfinite(se).all() and (se>0).all():crit=float(np.quantile(np.max(np.abs((mat[good]-obs[md])/se),axis=1),.95,method='median_unbiased'))
        with np.errstate(over='ignore'):
            lower=np.exp(obs[md]-crit*se);upper=np.exp(obs[md]+crit*se)
        for j,(a,b) in enumerate(ij):rows.append(dict(model=md,block_length=L,stratified=stratified,bootstrap_attempts=B,finite_count=cnt,failure_rate=1-cnt/B,critical_value=crit,pair=names[a]+'/'+names[b],estimate=np.exp(obs[md][j]),se_log=se[j],lower=lower[j],upper=upper[j],excludes_one=bool(lower[j]>1 or upper[j]<1)))
    return pd.DataFrame(rows),draws

def correlations(x,names,dates,out):
    rows=[];index={day:i for i,day in enumerate(dates.to_numpy().astype('datetime64[D]').astype(np.int64))};days=np.array(list(index))
    for name,y in zip(names,x.T):
        for lag in range(1,31):
            pairs=[(i,index[int(t+lag)]) for i,t in enumerate(days) if int(t+lag) in index];i,j=np.array(pairs).T;a=y[i];b=y[j];wet=(a>0)&(b>0)
            rows.append(dict(province=name,lag_days=lag,wet_indicator_correlation=np.corrcoef(a>0,b>0)[0,1],log_positive_correlation=np.corrcoef(np.log(a[wet]),np.log(b[wet]))[0,1] if wet.sum()>=3 else np.nan,log_positive_pairs=int(wet.sum())))
    write(pd.DataFrame(rows),out/'calendar_lag_correlations.csv');write(pd.DataFrame(np.corrcoef((x>0).T),index=names,columns=names),out/'same_day_wet_correlations.csv',index=True)
    logs=np.full_like(x,np.nan);logs[x>0]=np.log(x[x>0]);write(pd.DataFrame(logs,columns=names).corr(),out/'same_day_logpositive_correlations.csv',index=True)

def figures(x,names,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    cols=dict(LN='#0072B2',Gamma='#D55E00',Exponential='#009E73',Normal='#CC79A7')
    for kind in ['density','logpositive']:
        fig,axs=plt.subplots(2,2,figsize=(8,6))
        for ax,name,y in zip(axs.flat,names,x.T):
            y=y[y>0];ax.set_title(name)
            if kind=='density':
                ax.hist(y,bins='fd',density=True,color='#EEEEEE',edgecolor='white');grid=np.linspace(0,y.max(),800)
                for md,col in cols.items():ax.plot(grid,positive_fit(y,md)['dist'].pdf(grid),color=col,label=md,lw=1.2)
                ax.set_xlabel('Positive daily rainfall (mm)')
            else:
                a=np.log(y);ax.hist(a,bins='fd',density=True,color='#EEEEEE',edgecolor='white');grid=np.linspace(a.min(),a.max(),800);ax.plot(grid,stats.gaussian_kde(a)(grid),label='Empirical density',color='#0072B2');ax.plot(grid,stats.norm.pdf(grid,a.mean(),a.std(ddof=0)),label='Fitted normal',color='#D55E00');ax.set_xlabel('Log positive daily rainfall')
            ax.set_ylabel('Density');ax.legend(fontsize=7,frameon=False)
        stem='Figure6_positive_rainfall' if kind=='density' else 'Figure7_log_positive_rainfall'
        fig.tight_layout(pad=1.1)
        for ext in ['png','svg']:fig.savefig(out/(stem+'.'+ext),dpi=300,bbox_inches='tight')
        plt.close(fig)
    qq=[];fig,axs=plt.subplots(4,2,figsize=(8,8))
    for i,(name,y) in enumerate(zip(names,x.T)):
        y=np.sort(y[y>0]);n=len(y);pp=(np.arange(1,n+1)-.5)/n # R ppoints when n>10
        for j,md in enumerate(['LN','Gamma']):
            th=positive_fit(y,md)['dist'].ppf(pp);qq.extend(dict(province=name,model=md,observed=a,theoretical=b,probability=p) for a,b,p in zip(y,th,pp));ax=axs[i,j];ax.scatter(th,y,s=5,color='#0072B2');ma=max(y.max(),th.max());ax.plot([0,ma],[0,ma],'--',color='#D55E00');ax.set_title(name+' '+md);ax.set_xlabel('Fitted quantile (mm)');ax.set_ylabel('Observed (mm)')
    write(pd.DataFrame(qq),out/'QQ_plot_data.csv')
    fig.tight_layout(pad=1.1)
    for ext in ['png','svg']:fig.savefig(out/('Figure_QQ_LN_Gamma.'+ext),dpi=300,bbox_inches='tight')
    plt.close(fig)

def write(df,path,index=False):df.to_csv(path,index=index,na_rep='NA')

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--data',default=str(Path(__file__).with_name('data_rainfalls_NE.csv')));pa.add_argument('--out',default='results_empirical');pa.add_argument('--draws',type=int,default=5000);pa.add_argument('--bootstrap',type=int,default=5000);pa.add_argument('--repeats',type=int,default=30);pa.add_argument('--seed',type=int,default=20261003);pa.add_argument('--mode',choices=['intervals','full'],default='full');a=pa.parse_args()
    if sys.version_info[:3]!=(3,14,7):raise SystemExit('Use Python 3.14.7; check .venv\\Scripts\\python.exe --version')
    if min(a.draws,a.bootstrap)<100 or not 2<=a.repeats<=100000:raise ValueError('Require draws/bootstrap >=100 and repeats in 2..100000')
    out=Path(a.out)
    if out.exists() and any(out.iterdir()):raise ValueError('Output is not empty. Choose a NEW --out directory; no existing results are overwritten.')
    out.mkdir(parents=True,exist_ok=True);dat=pd.read_csv(a.data,encoding='utf-8-sig');dates=pd.DatetimeIndex(pd.to_datetime(dat.pop('date'),format='%d/%m/%Y',errors='raise'));names=list(dat);x=dat.to_numpy(dtype=float)
    if len(names)<2 or dates.hasnans or dates.has_duplicates or not dates.is_monotonic_increasing or not np.isfinite(x).all() or (x<0).any():raise ValueError('Invalid dates or rainfall data')
    write(pd.DataFrame([dict(rows=len(x),populations=len(names),first_date=str(dates[0].date()),last_date=str(dates[-1].date()),missing_calendar_dates=len(pd.date_range(dates[0],dates[-1]).difference(dates)),duplicate_dates=0,missing_values=0,negative_values=0)]),out/'data_audit.csv')
    meta=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,pandas=pd.__version__,rng='PCG64DXSM',inner_draws=a.draws,validation_draws_per_prior=a.draws,bootstrap_attempts=a.bootstrap,seed=a.seed,alpha=.05,k=len(names),pairs=len(pairs_for(len(names))),quantile='median_unbiased (R type 8)',HPD_scale='original_ratio',mode=a.mode,repeats=a.repeats)
    (out/'run_settings.json').write_text(json.dumps(meta,indent=2));write(pd.DataFrame([meta]),out/'run_metadata.csv');(out/'sessionInfo.txt').write_text(sys.version+'\n'+platform.platform()+'\n'+json.dumps(meta,indent=2));write(pd.DataFrame([dict(file=p.name,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [Path(a.data),Path(__file__),Path(__file__).with_name('ziln_core.py')]]),out/'input_code_SHA256.csv')
    desc=describe(x,names);write(desc,out/'Table2_rainfall_summary.csv');ci,dg=construct(x,a.draws,a.seed,900);tab=interval_table(x,names,ci,'full');write(tab,out/'Table4_intervals_long.csv');wide=tab.pivot(index='pair',columns='method',values=['lower','upper']).reindex(tab.pair.unique());w=pd.DataFrame(dict(pair=wide.index,estimate=tab.drop_duplicates('pair').estimate.to_numpy()))
    for m in METHODS:w[m]=[f'[{lo:.4f}, {hi:.4f}]' for lo,hi in ci[m]]
    write(w,out/'Table4_for_manuscript.csv');write(pd.DataFrame([dict(method=m,validation_draws=a.draws,joint_posterior_mass=dg['posterior_joint_mass'][m],MCSE=np.sqrt(dg['posterior_joint_mass'][m]*(1-dg['posterior_joint_mass'][m])/a.draws)) for m in POSTERIOR_METHODS]),out/'posterior_validation.csv');write(pd.DataFrame([dict(method=m,status=dg['status'][m],eligible=dg['mathematically_eligible'][m]) for m in METHODS]),out/'interval_status.csv');print('Primary Table 4 complete',flush=True)
    if a.mode=='intervals':return
    fits=[];ad=[];adraw={};j=0
    for name,y in zip(names,x.T):
        y=y[y>0]
        for md in ['LN','Gamma','Exponential','Normal']:
            f=positive_fit(y,md);fits.append(dict(province=name,model=md,positive_count=len(y),logLik=f['ll'],AIC=f['AIC'],BIC=f['BIC']))
        for md in ['LN','Gamma']:
            j+=1;s,v=ad_bootstrap(y,md,a.bootstrap,a.seed+j*1009);ad.append(dict(province=name,**s));adraw[name+'_'+md]=v;print('AD complete:',name,md,flush=True)
    write(pd.DataFrame(fits),out/'Table3_positive_fits.csv');write(pd.DataFrame(ad),out/'AD_bootstrap_results.csv');np.savez_compressed(out/'AD_bootstrap_statistics.npz',**adraw)
    wet=np.isin(dates.month,np.arange(5,11));seas=[];sdesc=[]
    for j,(label,mask) in enumerate([('wet',wet),('dry',~wet)],1):
        xx=x[mask];cc,dd=construct(xx,a.draws,a.seed,900+j);seas.append(interval_table(xx,names,cc,label));sdesc.append(describe(xx,names,label))
    write(pd.concat(seas),out/'seasonal_intervals.csv');write(pd.concat(sdesc),out/'seasonal_descriptive.csv');correlations(x,names,dates,out)
    blocks=[];j=0
    for strat in [False,True]:
        for L in [7,14,30]:
            j+=1;b,v=block_compare(x,names,dates,L,a.bootstrap,a.seed+100000+j*1009,strat);blocks.append(b);np.savez_compressed(out/f'block_draws_L{L}_strat{strat}.npz',**v);print('Block complete:',L,'stratified',strat,flush=True)
    write(pd.concat(blocks),out/'block_model_sensitivity.csv');stable=[]
    for rep in range(1,a.repeats+1):
        cc,_=construct(x,a.draws,a.seed,910,rep);tt=interval_table(x,names,cc,'full');tt.insert(0,'construction_repeat',rep);stable.append(tt)
    write(pd.concat(stable),out/'endpoint_repeated.csv');figures(x,names,out)
    assert len(tab)==len(METHODS)*len(pairs_for(len(names)))
    assert np.isclose(desc.loc[desc.province.eq('Mahasarakham'),'CV'].iloc[0],8.46954255855776,rtol=1e-12)
    print('FULL EMPIRICAL ANALYSIS COMPLETE',flush=True)

if __name__=='__main__':main()
