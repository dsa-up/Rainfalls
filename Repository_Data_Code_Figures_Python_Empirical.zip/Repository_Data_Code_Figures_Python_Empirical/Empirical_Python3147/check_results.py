"""Validate a completed FULL run and compare deterministic statistics with R."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--out',default='results_full');a=p.parse_args();out=Path(a.out);home=Path(__file__).parent
meta=json.loads((out/'run_settings.json').read_text());checks=[]
for fn,keys,cols in [('Table2_rainfall_summary.csv',['province'],['n','positive','delta','mu','variance_unbiased','CV']),('Table3_positive_fits.csv',['province','model'],['logLik','AIC','BIC']),('AD_bootstrap_results.csv',['province','model'],['AD'])]:
    new=pd.read_csv(out/fn).set_index(keys);old=pd.read_csv(home/'reference_R_deterministic'/fn).set_index(keys);new=new.reindex(old.index)
    assert np.isfinite(new[cols].to_numpy()).all(),fn
    np.testing.assert_allclose(new[cols],old[cols],rtol=2e-9,atol=1e-7,err_msg=fn)
    checks.append(dict(check=fn+' deterministic quantities vs R',passed=True,max_absolute_error=float(np.max(np.abs(new[cols].to_numpy()-old[cols].to_numpy())))))
ci=pd.read_csv(out/'Table4_intervals_long.csv');assert len(ci)==36 and not ci.duplicated(['method','pair']).any();assert np.isfinite(ci[['lower','upper']]).all().all() and (ci.lower>0).all() and (ci.lower<=ci.upper).all()
ad=pd.read_csv(out/'AD_bootstrap_results.csv');assert len(ad)==8 and (ad.finite_count+ad.failures).eq(meta['bootstrap_attempts']).all()
bl=pd.read_csv(out/'block_model_sensitivity.csv');assert len(bl)==72 and not bl.duplicated(['model','block_length','stratified','pair']).any();assert bl.finite_count.le(meta['bootstrap_attempts']).all()
rr=pd.read_csv(out/'endpoint_repeated.csv');assert len(rr)==meta['repeats']*36 and not rr.duplicated(['construction_repeat','method','pair']).any()
assert len(pd.read_csv(out/'seasonal_intervals.csv'))==72
assert len(pd.read_csv(out/'calendar_lag_correlations.csv'))==120
checks.extend([dict(check='complete interval/AD/block/seasonal/repeated/correlation exports',passed=True),dict(check='Python version',passed=meta['python']=='3.14.7')]);assert all(c['passed'] for c in checks)
(out/'validation_report.json').write_text(json.dumps(checks,indent=2));print('ALL CHECKS PASSED')
for c in checks:print(c)
