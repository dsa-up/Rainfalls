"""Regenerate Figure 6-7 and QQ diagnostics only; no bootstrap rerun."""
import argparse,sys
from pathlib import Path
import numpy as np
import pandas as pd
from run_empirical import figures
p=argparse.ArgumentParser();p.add_argument('--data',default=str(Path(__file__).with_name('data_rainfalls_NE.csv')));p.add_argument('--out',default='figures_only');a=p.parse_args()
if sys.version_info[:3]!=(3,14,7):raise SystemExit('Use Python 3.14.7')
d=pd.read_csv(a.data,encoding='utf-8-sig');dates=pd.to_datetime(d.pop('date'),format='%d/%m/%Y');x=d.to_numpy(dtype=float)
if dates.isna().any() or dates.duplicated().any() or not dates.is_monotonic_increasing or not np.isfinite(x).all() or (x<0).any():raise ValueError('Invalid rainfall input')
out=Path(a.out)
if out.exists() and any(out.iterdir()):raise ValueError('Use a NEW --out folder')
out.mkdir(parents=True,exist_ok=True);figures(x,list(d),out);print('FIGURES 6-7 COMPLETE')
