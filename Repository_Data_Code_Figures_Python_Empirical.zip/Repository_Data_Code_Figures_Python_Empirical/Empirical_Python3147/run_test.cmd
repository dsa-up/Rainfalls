@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe run_empirical.py --mode full --draws 200 --bootstrap 100 --repeats 3 --seed 20261003 --out results_test
