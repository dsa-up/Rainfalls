Empirical study ด้วย Python 3.14.7

ผล Table 4, Figure 6-7 และผล sensitivity ทั้งหมดใน manuscript ฉบับนี้มาจาก Python
ไม่ใช่การเปลี่ยนชื่อซอฟต์แวร์ในข้อความเพียงอย่างเดียว
Python และ R ใช้ตัวสร้างเลขสุ่มต่างกัน แม้ seed เท่ากัน ปลายช่วงไม่จำเป็นต้องเท่ากัน
ชุดนี้ใช้ PCG64DXSM เหมือนโค้ด simulation Python ที่ตรวจแล้ว

1. แตก ZIP ลงโฟลเดอร์ใหม่ เช่น E:\ZILN_Empirical_Python3147
2. เปิด Command Prompt แล้วพิมพ์:
   cd /d E:\ZILN_Empirical_Python3147
   py -3.14 --version
   ต้องได้ Python 3.14.7
3. ติดตั้ง dependencies:
   setup.cmd
   .venv\Scripts\python.exe --version
   ต้องได้ Python 3.14.7 เช่นกัน

ทดสอบกระบวนการทั้งหมดก่อน (draws 200, bootstrap 100, repeats 3):
.venv\Scripts\python.exe run_empirical.py --mode full --draws 200 --bootstrap 100 --repeats 3 --seed 20261003 --out results_test
.venv\Scripts\python.exe check_results.py --out results_test
ต้องจบด้วย FULL EMPIRICAL ANALYSIS COMPLETE และ ALL CHECKS PASSED
ชุดทดสอบตรวจการทำงาน ไม่ใช่ผลสำหรับ manuscript

รันผลจริงทั้งชุด:
.venv\Scripts\python.exe run_empirical.py --mode full --draws 5000 --bootstrap 5000 --repeats 30 --seed 20261003 --out results_full
.venv\Scripts\python.exe check_results.py --out results_full

สร้างเฉพาะ Table 4 และการตรวจ posterior (ไม่สร้าง Figure 6-7 หรือ sensitivity):
.venv\Scripts\python.exe run_empirical.py --mode intervals --draws 5000 --out results_intervals
คำสั่ง check_results.py ใช้กับ mode full เท่านั้น

ทุกคำสั่งด้านบนเป็นคำสั่งบรรทัดเดียว ใช้ใน Command Prompt ได้เลย
โปรแกรมไม่เขียนทับโฟลเดอร์ที่มีผลแล้ว หากจะรันซ้ำให้เปลี่ยน --out เช่น results_full_2
ไม่มีการรัน simulation 129 scenarios ซ้ำในแพ็กเกจ empirical นี้

ผลหลักที่ควรตรวจใน results_full:
- Table2_rainfall_summary.csv: CV และพารามิเตอร์
- Table3_positive_fits.csv: likelihood/AIC/BIC
- Table4_for_manuscript.csv และ Table4_intervals_long.csv: ช่วงใหม่จาก Python
- posterior_validation.csv และ interval_status.csv
- AD_bootstrap_results.csv: AD และ bootstrap p-values (plus-one correction)
- block_model_sensitivity.csv: block bootstrap 7/14/30 วันทั้งสองรูปแบบ
- seasonal_intervals.csv และ seasonal_descriptive.csv
- endpoint_repeated.csv: ผลสร้างช่วงซ้ำ 30 ครั้ง
- Figure6_positive_rainfall.png/.svg และ Figure7_log_positive_rainfall.png/.svg
- QQ_plot_data.csv และ Figure_QQ_LN_Gamma.png/.svg
- run_settings.json, sessionInfo.txt และ input_code_SHA256.csv
- validation_report.json หลังผ่าน check_results.py
- *.npz เป็น arrays ของ bootstrap draws ที่อ่านด้วย numpy.load ได้

โฟลเดอร์ verified_results_full และ verified_results_test ใน ZIP คือผลที่ได้ตรวจรันไว้แล้ว
reference_R_deterministic ใช้เทียบเฉพาะสถิติที่ไม่ขึ้นกับการสุ่ม ไม่ใช้ผล R แทนผล Python
Table 4 Python รอบหลักให้ทุกวิธีครอบคลุม 1 สำหรับ Khonkaen/Kalasin
การสร้างซ้ำ 30 ครั้งยังแสดงความไวของคู่นี้ จึงต้องใช้ manuscript ฉบับ Python คู่กับผลนี้

สร้างเฉพาะ Figure 6-7 และ QQ plots โดยไม่ทำ bootstrap ใหม่:
.venv\Scripts\python.exe make_figures_6_7.py --out figures_only
