@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe run_empirical.py --mode full --draws 5000 --bootstrap 5000 --repeats 30 --seed 20261003 --out results_full
