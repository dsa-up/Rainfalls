@echo off
setlocal
cd /d "%~dp0"
py -3.14 -c "import sys; assert sys.version_info[:3] == (3,14,7), 'Python 3.14.7 is required'"
if errorlevel 1 goto fail
if not exist .venv\Scripts\python.exe py -3.14 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -c "import sys; assert sys.version_info[:3] == (3,14,7), 'Existing .venv is not Python 3.14.7; use a new project folder'"
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements-tested.txt
if errorlevel 1 goto fail
echo Setup complete.
exit /b 0
:fail
echo Setup failed. Read the error above.
exit /b 1
