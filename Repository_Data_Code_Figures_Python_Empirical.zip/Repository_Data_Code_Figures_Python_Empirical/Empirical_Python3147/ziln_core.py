"""Faithful formula port of attached ziln_core.R. Arrays: draws x populations/pairs."""
import itertools
import numpy as np

METHODS = ('GCI','ETI_IndJ','ETI_Uniform','HPD_IndJ','HPD_Uniform','FGCI')
POSTERIOR_METHODS = METHODS[1:5]

def seed_key(root, case, rep, stream):
    if not (1 <= case <= 1000 and 1 <= rep <= 100000 and 0 <= stream <= 7):
        raise ValueError('Seed key outside supported range')
    return int((int(root) + 104729*((case-1)*800000+(rep-1)*8+stream)) % 2147483647)

def rng_for(seed):
    return np.random.Generator(np.random.PCG64DXSM(int(seed)))

def pairs_for(k):
    return np.array(list(itertools.combinations(range(k),2)),dtype=int)

def logcv(v,p):
    with np.errstate(all='ignore'):
        return .5*(np.asarray(v)-np.log(p)+np.log(-np.expm1(np.log(p)-v)))

def fit_ziln(x):
    x=np.asarray(x,dtype=float)
    if x.ndim!=1 or len(x)<2 or not np.isfinite(x).all() or (x<0).any():
        raise ValueError('Each population must contain >=2 finite nonnegative values')
    y=np.log(x[x>0]);r=len(y);n=len(x)
    mu=float(np.mean(y)) if r else np.nan
    S=float(np.sum((y-mu)**2)) if r>=2 else np.nan
    return dict(n=n,r=r,z=n-r,p=r/n,mu=mu,S=S,v=S/(r-1) if r>=2 else np.nan)

def generate(n,delta,mu,v,rng):
    x=np.zeros(n);wet=rng.random(n)>=delta
    x[wet]=rng.lognormal(mu,np.sqrt(v),int(wet.sum()))
    return x

def logratios(lc,ij):
    return lc[:,ij[:,0]]-lc[:,ij[:,1]]

def shortest_log(y,mass):
    y=np.sort(y);h=max(0,int(np.ceil(len(y)*mass))-1)
    if h>=len(y)-1:
        with np.errstate(over='ignore',under='ignore'): return np.exp(y[[0,-1]])
    lo=y[:len(y)-h];hi=y[h:]
    with np.errstate(all='ignore'): width=hi+np.log(-np.expm1(lo-hi))
    j=int(np.argmin(width))
    with np.errstate(over='ignore',under='ignore'): return np.exp([lo[j],hi[j]])

def family_from_log(lr,alpha,short=False):
    lr=np.asarray(lr);m=lr.shape[1]
    if not np.isfinite(lr).all(): return np.full((m,2),np.nan)
    if short: return np.array([shortest_log(lr[:,j],1-alpha/m) for j in range(m)])
    # R quantile(type=8) = NumPy median_unbiased. Keep quantiles in log domain.
    with np.errstate(over='ignore',under='ignore'):
        return np.exp(np.quantile(lr,[alpha/(2*m),1-alpha/(2*m)],axis=0,method='median_unbiased').T)

def fiducial_positive(a,B,rng):
    lower=rng.beta(a['r'],a['z']+1,B)
    upper=np.ones(B) if a['z']==0 else rng.beta(a['r']+1,a['z'],B)
    return (lower+upper)/2

def posterior_logdraws(f,B,prior,rng):
    v=np.column_stack([1/rng.gamma((a['r']-1)/2 if prior=='IndJ' else (a['r']-3)/2,2/a['S'],B) for a in f])
    p=np.column_stack([rng.beta(a['r']+.5,a['z']+.5,B) if prior=='IndJ' else rng.beta(a['r']+1,a['z']+1,B) for a in f])
    return logcv(v,p)

def intervals(x,B=5000,alpha=.05,seeds=None):
    if B<2 or not 0<alpha<1 or len(x)<2: raise ValueError('Invalid B, alpha or K')
    if seeds is None: raise ValueError('Explicit independent stream seeds are required')
    if len(seeds)!=6: raise ValueError('Six seeds are required')
    f=[fit_ziln(xx) for xx in x];ij=pairs_for(len(f));m=len(ij)
    ans={nm:np.full((m,2),np.nan) for nm in METHODS}
    valid=all(a['r']>=2 and np.isfinite(a['S']) and a['S']>0 for a in f)
    elig={nm:valid and (not 'Uniform' in nm or all(a['r']>=4 for a in f)) for nm in METHODS}
    dg=dict(positive=[a['r'] for a in f],fiducial_failed=None,
            posterior_joint_mass={nm:np.nan for nm in POSTERIOR_METHODS},validation_draws=B,
            mathematically_eligible=elig,status={nm:'ineligible' for nm in METHODS})
    if not valid: return ans,dg
    rng=rng_for(seeds[0])
    vg=np.column_stack([a['S']/rng.chisquare(a['r']-1,B) for a in f])
    pp=[]
    for a in f:
        z=rng.standard_normal(B)
        qzero=(a['z']+z*z/2-z*np.sqrt(a['z']*(1-a['z']/a['n'])+z*z/4))/(a['n']+z*z)
        pp.append(1-qzero)
    ans['GCI']=family_from_log(logratios(logcv(vg,np.column_stack(pp)),ij),alpha)
    for prior,st,valst in [('IndJ',1,4),('Uniform',2,5)]:
        if not elig['ETI_'+prior]: continue
        with np.errstate(all='ignore'):
            lr=logratios(posterior_logdraws(f,B,prior,rng_for(seeds[st])),ij)
            vlr=logratios(posterior_logdraws(f,B,prior,rng_for(seeds[valst])),ij)
        for typ in ['ETI','HPD']:
            nm=typ+'_'+prior;cc=family_from_log(lr,alpha,typ=='HPD');ans[nm]=cc
            if np.isfinite(cc).all() and (cc>0).all():
                inside=(vlr>=np.log(cc[:,0])) & (vlr<=np.log(cc[:,1])) & np.isfinite(vlr)
                dg['posterior_joint_mass'][nm]=float(inside.all(axis=1).mean())
    rng=rng_for(seeds[3])
    vf=np.column_stack([a['S']/rng.chisquare(a['r']-1,B) for a in f])
    pf=np.column_stack([fiducial_positive(a,B,rng) for a in f])
    with np.errstate(all='ignore'): lr=logratios(logcv(vf,pf),ij)
    dg['fiducial_failed']=int((~np.isfinite(lr).all(axis=1)).sum())
    ans['FGCI']=family_from_log(lr,alpha)
    for nm in METHODS:
        if not elig[nm]: continue
        cc=ans[nm];malformed=np.isnan(cc).any() or (cc[:,0]<0).any() or (cc[:,0]>cc[:,1]).any()
        dg['status'][nm]='numerical_failure' if malformed else 'finite' if np.isfinite(cc).all() else 'infinite_endpoints'
        if malformed: ans[nm]=np.full((m,2),np.nan)
    return ans,dg
