DATA CODE AND NUMERICAL RESULTS

Study: Simultaneous intervals for pairwise coefficient of variation ratios in zero-inflated lognormal distributions
Public repository: https://github.com/dsa-up/Rainfalls

Download Repository_Data_Code_Figures_Python_Empirical.zip and extract it before opening files or running scripts. The manuscript and response letters are supplied separately.

CONTENTS
simulation_summary.csv: authoritative full simulation summary; 129 scenarios x 6 methods = 774 records. Every record represents 10,000 attempted datasets, with no replacement of failed attempts; construction draws B = 5,000.
Simulation_execution/run_settings.json: exact scenario parameter vectors, seed keys, settings and simulation source hashes.
Simulation_execution/sessionInfo.txt: recorded execution environment.
Simulation_code/: Python simulation source, requirements and Windows commands.
Table1b_data.csv: 24-scenario structured display subset (144 method records), corresponding to current manuscript Table 2. This file is not the complete design.
Online_Results_and_Diagnostics_Python.docx: detailed simulation results and empirical diagnostics for online access.
make_Figures_3_5.R: simulation plotting source; uses base R.
figures/: Figure 3-5 PNG/PDF exports, underlying plotting data and recorded R session information. Mean lengths use panel-specific log10 axes. Missing estimates are not plotted as zero, and finite widths are not capped.
Empirical_Python3147/: analysis-ready rainfall data, Python empirical source, pinned dependencies, setup and validation scripts.
Empirical_Python3147/verified_results_full/: primary empirical execution with construction draws 5,000, bootstrap attempts 5,000, 30 additional constructions and root seed 20261003. Includes model fits, interval endpoints, independent posterior validation, AD tests, seasonal analyses, calendar-lag and interprovincial diagnostics, block-model sensitivity, repeated endpoints, raw bootstrap arrays, figure data and validation reports.
Empirical_Python3147/verified_results_test/: small-run software checks; these are not manuscript estimates.
Empirical_Python3147/reference_R_deterministic/: historical deterministic reference quantities used for formula checks, not primary empirical randomization results.

CURRENT MANUSCRIPT TABLE MAPPING
The numerical CSV filenames retain earlier table numbers for reproducibility:
  Table2_rainfall_summary.csv -> manuscript Table 3
  Table3_positive_fits.csv -> manuscript Table 4
  Table4_for_manuscript.csv and Table4_intervals_long.csv -> manuscript Table 5
  Table1b_data.csv -> manuscript Table 2
Manuscript Table 1 summarizes ranges over all 129 scenarios.

RUNNING
Follow Empirical_Python3147/README_TH.txt and the relevant setup/test/full .cmd files. Use a new output directory for each new execution; verified_results_full is the archived primary result, not the default rerun destination.
Simulation execution used Python 3.14.7, NumPy 2.3.5, SciPy 1.17.0 and pandas 2.3.3. Empirical plotting additionally used Matplotlib 3.10.8. Figure 3-5 plotting source is R; Figure 6-7 plotting source is Python with SVG and PNG exports. Integer seeds shared between different software implementations do not imply identical streams.

INTERPRETATION
CP_joint_conditional and AL_finite use each method's complete finite families. CP_joint_unconditional is operational finite-family joint success over all attempted datasets. A missing conditional CP is undefined, not zero; operational CP is zero if no finite family is obtained. Counts, Monte Carlo uncertainty, common-subset summaries, medians and upper quantiles accompany the mean lengths. Recorded infinite endpoints may include overflow and do not prove theoretical unboundedness. Repeated endpoint constructions cover the rainfall application, not every simulation scenario.
